# smart-contract

Our LinkShield smart contract. Project from Web3 Week: https://www.luiztools.com.br/w3w

## How to Run

1. open https://remix.ethereum.org
2. create a new LinkShield.sol file
3. copy and paste the content from repo
4. compile & deploy
5. test

## More

Faucets: https://faucet.luiztools.com.br

MetaMask configuration: https://www.luiztools.com.br/post/como-configurar-a-metamask-para-desenvolvimento-blockchain/

Know my book: https://www.luiztools.com.br/livro-web3

Follow me on social networks for more: https://about.me/luiztools

Receive my news on Telegram: https://t.me/luiznews