# web3-week-7
Project from the seventh Web3 Week (04-aug-25). https://www.luiztools.com.br/w3w

## smart-contract
Our LinkShield.sol smart contract.

## dapp
Soon.

## Lives

Live 01: https://youtube.com/live/CaxB_C5XH3I?feature=share

Live 02: soon

Live 03: soon

Live 04: soon

Live 05: soon

## More

Know my book: https://www.luiztools.com.br/livro-web3

Follow me on social networks for more: https://about.me/luiztools

Receive my news on Telegram: https://t.me/luiznews
